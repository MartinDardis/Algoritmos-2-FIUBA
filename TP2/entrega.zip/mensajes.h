#define ERROR -1
#define CANT_PARAM_INCORRECTO "Cantidad de parametros invalida"
#define PARAM_INVALIDO "Parametro Incorrecto"
